#programa de sueldos

cantidad=int(input("ingrese la cantidad de empleados: "))

sueldo_bajo=0
sueldo_alto=0
total_sueldo=0
contador=0

while contador<cantidad:
    contador+=1
    sueldo=float(input("ingrese el salario del empleado: "))
    
    if sueldo<1000000 or sueldo>5000000:
        print("El sueldo debe estar entre 1000000 y 5000000")
        continue
    if sueldo<=3000000:
        sueldo_bajo+=1
         
    else:
            sueldo_alto+=1
    total_sueldo+=sueldo

#imprimir resultados
print("cantidad de empleados que gana entre 1000000 y 2999999 es: ",sueldo_bajo)
print("cantidad de empleados que gana entre 3000000 y 5000000 es: ",sueldo_alto)
print("el total de los sueldos es: ",total_sueldo)
            
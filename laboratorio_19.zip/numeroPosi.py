

while True: 
    numero = int(input("Digite un número positivo: "))
    if numero > 0 :
        
        print("Número positivo detectado. Fin del programa.")  
        break
    


if numero<10:
    print(" el numero es de un digito")
    
elif numero<100:
    print("el numero es de dos digitos")
else: 
    print("el numero es de 3 digitos")


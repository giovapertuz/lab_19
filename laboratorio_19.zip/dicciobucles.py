#Diccionario

estudiantes={
    "Ana":85,"pedro":92,"karla":78
}
#encontrar estudiantes calificacion mas alta
mejor_estudiante=max(estudiantes,key=estudiantes.get)
calificacion_alta=estudiantes[mejor_estudiante]
print(f"El estudiante con la calificacion mas alta es {mejor_estudiante} con una calificacion de {calificacion_alta} ")

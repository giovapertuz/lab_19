numero=int(input("digite un numero: "))

if numero%2==0:
    print("El numero ",numero," es par...")
else:
    print("El numero ",numero," es impar...")
    

#crear un diccionario para almacenar estudiantes y calificaciones
estudiantes = {}
while True:
    nombre=input("nombre del estudiante: ")
    calificaciones=float(input("calificacion: "))
    
  
    #verificar si el estudiante ya existe
    if nombre in estudiantes:
        print(f"{nombre} ya existe en el diccionario... actualizando informacion")
        estudiantes[nombre]=calificaciones
    else:
        print(f"{nombre} no existe en el diccionario... agregando al diccionario")
        estudiantes[nombre]=calificaciones
    salir=input("desea salir?(si/no)")
    if salir=='si':
      break
  
  
  

# Mostrar todos los estudiantes y sus calificaciones

print("\n estudiantes y sus calificaciones")

for nombre, calificaciones in estudiantes.items():
    print(f"\nEstudiante: {nombre}\nNota: {calificaciones}")


    
   
    


